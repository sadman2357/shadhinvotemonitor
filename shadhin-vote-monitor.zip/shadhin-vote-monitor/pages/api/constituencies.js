// API endpoint to fetch constituencies
// GET /api/constituencies?district=Dhaka

import { query } from '../../lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { district, division } = req.query;

    let sql = 'SELECT * FROM constituencies WHERE 1=1';
    const params = [];
    let paramCount = 1;

    if (district) {
      sql += ` AND district = $${paramCount}`;
      params.push(district);
      paramCount++;
    }

    if (division) {
      sql += ` AND division = $${paramCount}`;
      params.push(division);
      paramCount++;
    }

    sql += ' ORDER BY seat_number ASC';

    const result = await query(sql, params);

    return res.status(200).json({
      success: true,
      data: result.rows,
      count: result.rows.length
    });

  } catch (error) {
    console.error('Error fetching constituencies:', error);
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to fetch constituencies'
    });
  }
}
