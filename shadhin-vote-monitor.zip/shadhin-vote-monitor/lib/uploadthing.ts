// UploadThing Configuration for Shadhin Vote Monitor
// File upload handler using UploadThing service

import { createUploadthing, type FileRouter } from "uploadthing/next-legacy";

const f = createUploadthing();

// FileRouter for the app
export const uploadRouter = {
    // Media uploader for incident reports
    mediaUploader: f({
        image: {
            maxFileSize: "20MB",
            maxFileCount: 1,
        },
        video: {
            maxFileSize: "20MB",
            maxFileCount: 1,
        },
    })
        .middleware(async ({ req }) => {
            // Rate limiting check
            const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

            // Add IP hash for tracking (without storing actual IP)
            const crypto = require('crypto');
            const ipHash = crypto.createHash('sha256').update(ip + process.env.JWT_SECRET).digest('hex');

            return { ipHash };
        })
        .onUploadComplete(async ({ metadata, file }) => {
            console.log("Upload complete for IP hash:", metadata.ipHash);
            console.log("File URL:", file.url);

            // Return data to be sent to client
            return {
                uploadedBy: metadata.ipHash,
                fileUrl: file.url,
                fileName: file.name,
                fileSize: file.size,
                fileType: file.type
            };
        }),
} satisfies FileRouter;

export type OurFileRouter = typeof uploadRouter;
