# Bangladesh Constituencies Import Guide

## Overview
This guide explains how to import the Bangladesh parliamentary constituencies data into your database.

## Database Structure

### Constituencies Table
- **Total Seats**: 300 directly elected + 50 reserved for women
- **Divisions**: 8 administrative divisions
- **Districts**: 64 districts

### Schema
```sql
constituencies (
  id SERIAL PRIMARY KEY,
  constituency_code VARCHAR(20) UNIQUE,
  constituency_name VARCHAR(100),
  district VARCHAR(50),
  division VARCHAR(30),
  seat_number INTEGER
)
```

## Import Instructions

### Option 1: Using Docker (Recommended)

```bash
# Copy SQL file into running PostgreSQL container
docker cp database/constituencies.sql shadhin-vote-monitor-db-1:/tmp/constituencies.sql

# Execute the SQL file
docker exec -i shadhin-vote-monitor-db-1 psql -U postgres -d election_monitor -f /tmp/constituencies.sql
```

### Option 2: Using psql directly

```bash
psql -U postgres -d election_monitor -f database/constituencies.sql
```

### Option 3: Using pgAdmin or Database GUI
1. Open your database GUI
2. Connect to the `election_monitor` database
3. Open and execute `database/constituencies.sql`

## API Usage

### Get All Constituencies
```bash
GET /api/constituencies
```

### Get Constituencies by District
```bash
GET /api/constituencies?district=Dhaka
```

### Get Constituencies by Division
```bash
GET /api/constituencies?division=Dhaka
```

### Example Response
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "constituency_code": "DHAKA-1",
      "constituency_name": "Dhaka-1",
      "district": "Dhaka",
      "division": "Dhaka",
      "seat_number": 1
    }
  ],
  "count": 20
}
```

## Division Breakdown

| Division | Total Seats | Major Districts |
|----------|-------------|-----------------|
| Dhaka | 71 | Dhaka (20), Tangail (8), Gazipur (6) |
| Chattogram | 58 | Chattogram (16), Cumilla (11), Brahmanbaria (6) |
| Rajshahi | 39 | Bogura (7), Rajshahi (6), Naogaon (6) |
| Khulna | 35 | Jashore (6), Khulna (6), Kushtia (4) |
| Rangpur | 33 | Dinajpur (6), Rangpur (6), Gaibandha (5) |
| Mymensingh | 24 | Mymensingh (11), Jamalpur (5), Netrokona (5) |
| Barishal | 21 | Barishal (6), Patuakhali (4), Bhola (4) |
| Sylhet | 19 | Sylhet (6), Sunamganj (5), Moulivibazar (4) |

## Verification

After import, verify the data:

```sql
-- Count total constituencies
SELECT COUNT(*) FROM constituencies;

-- Count by division
SELECT division, COUNT(*) as seat_count 
FROM constituencies 
GROUP BY division 
ORDER BY seat_count DESC;

-- Count by district
SELECT district, COUNT(*) as seat_count 
FROM constituencies 
GROUP BY district 
ORDER BY seat_count DESC;
```

## Integration with Report Form

Update your report form to dynamically load constituencies:

```javascript
// Fetch constituencies when district is selected
const districtSelect = document.getElementById('district');
const constituencySelect = document.getElementById('constituency');

districtSelect.addEventListener('change', async (e) => {
  const district = e.target.value;
  
  const response = await fetch(`/api/constituencies?district=${district}`);
  const data = await response.json();
  
  constituencySelect.innerHTML = '<option value="">Select Constituency</option>';
  data.data.forEach(c => {
    const option = document.createElement('option');
    option.value = c.constituency_code;
    option.textContent = c.constituency_name;
    constituencySelect.appendChild(option);
  });
  
  constituencySelect.disabled = false;
});
```

## Notes

- The sample SQL file includes 146 constituencies as examples
- For production, you'll need all 300 constituencies
- Constituency codes follow the format: `DISTRICT-NUMBER` (e.g., DHAKA-1)
- Numbering starts from north and moves south as per Bangladesh Election Commission standards

## Resources

- [Bangladesh Parliament Website](http://www.parliament.gov.bd/)
- [Bangladesh Election Commission](http://www.ecs.gov.bd/)
