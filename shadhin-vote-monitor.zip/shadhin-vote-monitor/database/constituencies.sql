-- Bangladesh Parliamentary Constituencies Data - Complete Dataset
-- Jatiya Sangsad: 300 directly elected seats + 50 reserved seats for women
-- Data based on Bangladesh Election Commission official constituency list

CREATE TABLE IF NOT EXISTS constituencies (
    id SERIAL PRIMARY KEY,
    constituency_code VARCHAR(20) UNIQUE NOT NULL,
    constituency_name VARCHAR(100) NOT NULL,
    district VARCHAR(50) NOT NULL,
    division VARCHAR(30) NOT NULL,
    seat_number INTEGER NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_constituencies_district ON constituencies(district);
CREATE INDEX IF NOT EXISTS idx_constituencies_division ON constituencies(division);
CREATE INDEX IF NOT EXISTS idx_constituencies_code ON constituencies(constituency_code);

-- Clear existing data
TRUNCATE TABLE constituencies RESTART IDENTITY CASCADE;

-- ========================================
-- DHAKA DIVISION (71 seats)
-- ========================================

-- Dhaka District (20 seats)
INSERT INTO constituencies (constituency_code, constituency_name, district, division, seat_number) VALUES
('DHAKA-1', 'Dhaka-1 (Tejgaon)', 'Dhaka', 'Dhaka', 1),
('DHAKA-2', 'Dhaka-2 (Mohammadpur)', 'Dhaka', 'Dhaka', 2),
('DHAKA-3', 'Dhaka-3 (Dhanmondi)', 'Dhaka', 'Dhaka', 3),
('DHAKA-4', 'Dhaka-4 (Hazaribagh)', 'Dhaka', 'Dhaka', 4),
('DHAKA-5', 'Dhaka-5 (Sutrapur)', 'Dhaka', 'Dhaka', 5),
('DHAKA-6', 'Dhaka-6 (Lalbagh)', 'Dhaka', 'Dhaka', 6),
('DHAKA-7', 'Dhaka-7 (Motijheel)', 'Dhaka', 'Dhaka', 7),
('DHAKA-8', 'Dhaka-8 (Shahbagh)', 'Dhaka', 'Dhaka', 8),
('DHAKA-9', 'Dhaka-9 (Ramna)', 'Dhaka', 'Dhaka', 9),
('DHAKA-10', 'Dhaka-10 (Mirpur)', 'Dhaka', 'Dhaka', 10),
('DHAKA-11', 'Dhaka-11 (Pallabi)', 'Dhaka', 'Dhaka', 11),
('DHAKA-12', 'Dhaka-12 (Uttara)', 'Dhaka', 'Dhaka', 12),
('DHAKA-13', 'Dhaka-13 (Gulshan)', 'Dhaka', 'Dhaka', 13),
('DHAKA-14', 'Dhaka-14 (Badda)', 'Dhaka', 'Dhaka', 14),
('DHAKA-15', 'Dhaka-15 (Khilgaon)', 'Dhaka', 'Dhaka', 15),
('DHAKA-16', 'Dhaka-16 (Jatrabari)', 'Dhaka', 'Dhaka', 16),
('DHAKA-17', 'Dhaka-17 (Demra)', 'Dhaka', 'Dhaka', 17),
('DHAKA-18', 'Dhaka-18 (Keraniganj)', 'Dhaka', 'Dhaka', 18),
('DHAKA-19', 'Dhaka-19 (Nawabganj)', 'Dhaka', 'Dhaka', 19),
('DHAKA-20', 'Dhaka-20 (Dohar)', 'Dhaka', 'Dhaka', 20),

-- Faridpur District (4 seats)
('FARIDPUR-1', 'Faridpur-1', 'Faridpur', 'Dhaka', 21),
('FARIDPUR-2', 'Faridpur-2', 'Faridpur', 'Dhaka', 22),
('FARIDPUR-3', 'Faridpur-3', 'Faridpur', 'Dhaka', 23),
('FARIDPUR-4', 'Faridpur-4', 'Faridpur', 'Dhaka', 24),

-- Gazipur District (5 seats)
('GAZIPUR-1', 'Gazipur-1', 'Gazipur', 'Dhaka', 25),
('GAZIPUR-2', 'Gazipur-2', 'Gazipur', 'Dhaka', 26),
('GAZIPUR-3', 'Gazipur-3', 'Gazipur', 'Dhaka', 27),
('GAZIPUR-4', 'Gazipur-4 (Kapasia)', 'Gazipur', 'Dhaka', 28),
('GAZIPUR-5', 'Gazipur-5 (Sreepur)', 'Gazipur', 'Dhaka', 29),

-- Gopalganj District (3 seats)
('GOPALGANJ-1', 'Gopalganj-1', 'Gopalganj', 'Dhaka', 30),
('GOPALGANJ-2', 'Gopalganj-2', 'Gopalganj', 'Dhaka', 31),
('GOPALGANJ-3', 'Gopalganj-3 (Tungipara)', 'Gopalganj', 'Dhaka', 32),

-- Kishoreganj District (6 seats)
('KISHOREGANJ-1', 'Kishoreganj-1', 'Kishoreganj', 'Dhaka', 33),
('KISHOREGANJ-2', 'Kishoreganj-2', 'Kishoreganj', 'Dhaka', 34),
('KISHOREGANJ-3', 'Kishoreganj-3', 'Kishoreganj', 'Dhaka', 35),
('KISHOREGANJ-4', 'Kishoreganj-4', 'Kishoreganj', 'Dhaka', 36),
('KISHOREGANJ-5', 'Kishoreganj-5', 'Kishoreganj', 'Dhaka', 37),
('KISHOREGANJ-6', 'Kishoreganj-6', 'Kishoreganj', 'Dhaka', 38),

-- Madaripur District (3 seats)
('MADARIPUR-1', 'Madaripur-1', 'Madaripur', 'Dhaka', 39),
('MADARIPUR-2', 'Madaripur-2', 'Madaripur', 'Dhaka', 40),
('MADARIPUR-3', 'Madaripur-3', 'Madaripur', 'Dhaka', 41),

-- Manikganj District (3 seats)
('MANIKGANJ-1', 'Manikganj-1', 'Manikganj', 'Dhaka', 42),
('MANIKGANJ-2', 'Manikganj-2', 'Manikganj', 'Dhaka', 43),
('MANIKGANJ-3', 'Manikganj-3', 'Manikganj', 'Dhaka', 44),

-- Munshiganj District (3 seats)
('MUNSHIGANJ-1', 'Munshiganj-1', 'Munshiganj', 'Dhaka', 45),
('MUNSHIGANJ-2', 'Munshiganj-2', 'Munshiganj', 'Dhaka', 46),
('MUNSHIGANJ-3', 'Munshiganj-3', 'Munshiganj', 'Dhaka', 47),

-- Narayanganj District (5 seats)
('NARAYANGANJ-1', 'Narayanganj-1', 'Narayanganj', 'Dhaka', 48),
('NARAYANGANJ-2', 'Narayanganj-2', 'Narayanganj', 'Dhaka', 49),
('NARAYANGANJ-3', 'Narayanganj-3', 'Narayanganj', 'Dhaka', 50),
('NARAYANGANJ-4', 'Narayanganj-4 (Rupganj)', 'Narayanganj', 'Dhaka', 51),
('NARAYANGANJ-5', 'Narayanganj-5 (Sonargaon)', 'Narayanganj', 'Dhaka', 52),

-- Narsingdi District (5 seats)
('NARSINGDI-1', 'Narsingdi-1', 'Narsingdi', 'Dhaka', 53),
('NARSINGDI-2', 'Narsingdi-2', 'Narsingdi', 'Dhaka', 54),
('NARSINGDI-3', 'Narsingdi-3', 'Narsingdi', 'Dhaka', 55),
('NARSINGDI-4', 'Narsingdi-4', 'Narsingdi', 'Dhaka', 56),
('NARSINGDI-5', 'Narsingdi-5', 'Narsingdi', 'Dhaka', 57),

-- Rajbari District (2 seats)
('RAJBARI-1', 'Rajbari-1', 'Rajbari', 'Dhaka', 58),
('RAJBARI-2', 'Rajbari-2', 'Rajbari', 'Dhaka', 59),

-- Shariatpur District (3 seats)
('SHARIATPUR-1', 'Shariatpur-1', 'Shariatpur', 'Dhaka', 60),
('SHARIATPUR-2', 'Shariatpur-2', 'Shariatpur', 'Dhaka', 61),
('SHARIATPUR-3', 'Shariatpur-3', 'Shariatpur', 'Dhaka', 62),

-- Tangail District (8 seats)
('TANGAIL-1', 'Tangail-1', 'Tangail', 'Dhaka', 63),
('TANGAIL-2', 'Tangail-2', 'Tangail', 'Dhaka', 64),
('TANGAIL-3', 'Tangail-3', 'Tangail', 'Dhaka', 65),
('TANGAIL-4', 'Tangail-4', 'Tangail', 'Dhaka', 66),
('TANGAIL-5', 'Tangail-5', 'Tangail', 'Dhaka', 67),
('TANGAIL-6', 'Tangail-6', 'Tangail', 'Dhaka', 68),
('TANGAIL-7', 'Tangail-7', 'Tangail', 'Dhaka', 69),
('TANGAIL-8', 'Tangail-8', 'Tangail', 'Dhaka', 70),

-- ========================================
-- CHATTOGRAM DIVISION (58 seats)
-- ========================================

-- Bandarban District (1 seat)
('BANDARBAN-1', 'Bandarban-1', 'Bandarban', 'Chattogram', 71),

-- Brahmanbaria District (6 seats)
('BRAHMANBARIA-1', 'Brahmanbaria-1', 'Brahmanbaria', 'Chattogram', 72),
('BRAHMANBARIA-2', 'Brahmanbaria-2', 'Brahmanbaria', 'Chattogram', 73),
('BRAHMANBARIA-3', 'Brahmanbaria-3', 'Brahmanbaria', 'Chattogram', 74),
('BRAHMANBARIA-4', 'Brahmanbaria-4', 'Brahmanbaria', 'Chattogram', 75),
('BRAHMANBARIA-5', 'Brahmanbaria-5', 'Brahmanbaria', 'Chattogram', 76),
('BRAHMANBARIA-6', 'Brahmanbaria-6', 'Brahmanbaria', 'Chattogram', 77),

-- Chandpur District (5 seats)
('CHANDPUR-1', 'Chandpur-1', 'Chandpur', 'Chattogram', 78),
('CHANDPUR-2', 'Chandpur-2', 'Chandpur', 'Chattogram', 79),
('CHANDPUR-3', 'Chandpur-3', 'Chandpur', 'Chattogram', 80),
('CHANDPUR-4', 'Chandpur-4', 'Chandpur', 'Chattogram', 81),
('CHANDPUR-5', 'Chandpur-5', 'Chandpur', 'Chattogram', 82),

-- Chattogram District (16 seats)
('CHATTOGRAM-1', 'Chattogram-1 (Bandar)', 'Chattogram', 'Chattogram', 83),
('CHATTOGRAM-2', 'Chattogram-2 (Kotwali)', 'Chattogram', 'Chattogram', 84),
('CHATTOGRAM-3', 'Chattogram-3 (Panchlaish)', 'Chattogram', 'Chattogram', 85),
('CHATTOGRAM-4', 'Chattogram-4 (Khulshi)', 'Chattogram', 'Chattogram', 86),
('CHATTOGRAM-5', 'Chattogram-5 (Halishahar)', 'Chattogram', 'Chattogram', 87),
('CHATTOGRAM-6', 'Chattogram-6 (Pahartali)', 'Chattogram', 'Chattogram', 88),
('CHATTOGRAM-7', 'Chattogram-7 (Raozan)', 'Chattogram', 'Chattogram', 89),
('CHATTOGRAM-8', 'Chattogram-8 (Patiya)', 'Chattogram', 'Chattogram', 90),
('CHATTOGRAM-9', 'Chattogram-9 (Anwara)', 'Chattogram', 'Chattogram', 91),
('CHATTOGRAM-10', 'Chattogram-10 (Boalkhali)', 'Chattogram', 'Chattogram', 92),
('CHATTOGRAM-11', 'Chattogram-11 (Chandanaish)', 'Chattogram', 'Chattogram', 93),
('CHATTOGRAM-12', 'Chattogram-12 (Satkania)', 'Chattogram', 'Chattogram', 94),
('CHATTOGRAM-13', 'Chattogram-13 (Lohagara)', 'Chattogram', 'Chattogram', 95),
('CHATTOGRAM-14', 'Chattogram-14 (Sandwip)', 'Chattogram', 'Chattogram', 96),
('CHATTOGRAM-15', 'Chattogram-15 (Banshkhali)', 'Chattogram', 'Chattogram', 97),
('CHATTOGRAM-16', 'Chattogram-16 (Sitakunda)', 'Chattogram', 'Chattogram', 98),

-- Cumilla District (11 seats)
('CUMILLA-1', 'Cumilla-1', 'Cumilla', 'Chattogram', 99),
('CUMILLA-2', 'Cumilla-2', 'Cumilla', 'Chattogram', 100),
('CUMILLA-3', 'Cumilla-3', 'Cumilla', 'Chattogram', 101),
('CUMILLA-4', 'Cumilla-4', 'Cumilla', 'Chattogram', 102),
('CUMILLA-5', 'Cumilla-5', 'Cumilla', 'Chattogram', 103),
('CUMILLA-6', 'Cumilla-6', 'Cumilla', 'Chattogram', 104),
('CUMILLA-7', 'Cumilla-7', 'Cumilla', 'Chattogram', 105),
('CUMILLA-8', 'Cumilla-8', 'Cumilla', 'Chattogram', 106),
('CUMILLA-9', 'Cumilla-9', 'Cumilla', 'Chattogram', 107),
('CUMILLA-10', 'Cumilla-10', 'Cumilla', 'Chattogram', 108),
('CUMILLA-11', 'Cumilla-11', 'Cumilla', 'Chattogram', 109),

-- Cox's Bazar District (4 seats)
('COXSBAZAR-1', 'Cox''s Bazar-1', 'Cox''s Bazar', 'Chattogram', 110),
('COXSBAZAR-2', 'Cox''s Bazar-2', 'Cox''s Bazar', 'Chattogram', 111),
('COXSBAZAR-3', 'Cox''s Bazar-3', 'Cox''s Bazar', 'Chattogram', 112),
('COXSBAZAR-4', 'Cox''s Bazar-4', 'Cox''s Bazar', 'Chattogram', 113),

-- Feni District (3 seats)
('FENI-1', 'Feni-1', 'Feni', 'Chattogram', 114),
('FENI-2', 'Feni-2', 'Feni', 'Chattogram', 115),
('FENI-3', 'Feni-3', 'Feni', 'Chattogram', 116),

-- Khagrachhari District (1 seat)
('KHAGRACHHARI-1', 'Khagrachhari-1', 'Khagrachhari', 'Chattogram', 117),

-- Lakshmipur District (4 seats)
('LAKSHMIPUR-1', 'Lakshmipur-1', 'Lakshmipur', 'Chattogram', 118),
('LAKSHMIPUR-2', 'Lakshmipur-2', 'Lakshmipur', 'Chattogram', 119),
('LAKSHMIPUR-3', 'Lakshmipur-3', 'Lakshmipur', 'Chattogram', 120),
('LAKSHMIPUR-4', 'Lakshmipur-4', 'Lakshmipur', 'Chattogram', 121),

-- Noakhali District (6 seats)
('NOAKHALI-1', 'Noakhali-1', 'Noakhali', 'Chattogram', 122),
('NOAKHALI-2', 'Noakhali-2', 'Noakhali', 'Chattogram', 123),
('NOAKHALI-3', 'Noakhali-3', 'Noakhali', 'Chattogram', 124),
('NOAKHALI-4', 'Noakhali-4', 'Noakhali', 'Chattogram', 125),
('NOAKHALI-5', 'Noakhali-5', 'Noakhali', 'Chattogram', 126),
('NOAKHALI-6', 'Noakhali-6', 'Noakhali', 'Chattogram', 127),

-- Rangamati District (1 seat)
('RANGAMATI-1', 'Rangamati-1', 'Rangamati', 'Chattogram', 128),

-- ========================================
-- RAJSHAHI DIVISION (39 seats)
-- ========================================

-- Bogura District (7 seats)
('BOGURA-1', 'Bogura-1', 'Bogura', 'Rajshahi', 129),
('BOGURA-2', 'Bogura-2', 'Bogura', 'Rajshahi', 130),
('BOGURA-3', 'Bogura-3', 'Bogura', 'Rajshahi', 131),
('BOGURA-4', 'Bogura-4', 'Bogura', 'Rajshahi', 132),
('BOGURA-5', 'Bogura-5', 'Bogura', 'Rajshahi', 133),
('BOGURA-6', 'Bogura-6', 'Bogura', 'Rajshahi', 134),
('BOGURA-7', 'Bogura-7', 'Bogura', 'Rajshahi', 135),

-- Joypurhat District (2 seats)
('JOYPURHAT-1', 'Joypurhat-1', 'Joypurhat', 'Rajshahi', 136),
('JOYPURHAT-2', 'Joypurhat-2', 'Joypurhat', 'Rajshahi', 137),

-- Naogaon District (6 seats)
('NAOGAON-1', 'Naogaon-1', 'Naogaon', 'Rajshahi', 138),
('NAOGAON-2', 'Naogaon-2', 'Naogaon', 'Rajshahi', 139),
('NAOGAON-3', 'Naogaon-3', 'Naogaon', 'Rajshahi', 140),
('NAOGAON-4', 'Naogaon-4', 'Naogaon', 'Rajshahi', 141),
('NAOGAON-5', 'Naogaon-5', 'Naogaon', 'Rajshahi', 142),
('NAOGAON-6', 'Naogaon-6', 'Naogaon', 'Rajshahi', 143),

-- Natore District (4 seats)
('NATORE-1', 'Natore-1', 'Natore', 'Rajshahi', 144),
('NATORE-2', 'Natore-2', 'Natore', 'Rajshahi', 145),
('NATORE-3', 'Natore-3', 'Natore', 'Rajshahi', 146),
('NATORE-4', 'Natore-4', 'Natore', 'Rajshahi', 147),

-- Nawabganj (Chapai Nawabganj) District (3 seats)
('NAWABGANJ-1', 'Nawabganj-1', 'Nawabganj', 'Rajshahi', 148),
('NAWABGANJ-2', 'Nawabganj-2', 'Nawabganj', 'Rajshahi', 149),
('NAWABGANJ-3', 'Nawabganj-3', 'Nawabganj', 'Rajshahi', 150),

-- Pabna District (5 seats)
('PABNA-1', 'Pabna-1', 'Pabna', 'Rajshahi', 151),
('PABNA-2', 'Pabna-2', 'Pabna', 'Rajshahi', 152),
('PABNA-3', 'Pabna-3', 'Pabna', 'Rajshahi', 153),
('PABNA-4', 'Pabna-4', 'Pabna', 'Rajshahi', 154),
('PABNA-5', 'Pabna-5', 'Pabna', 'Rajshahi', 155),

-- Rajshahi District (6 seats)
('RAJSHAHI-1', 'Rajshahi-1', 'Rajshahi', 'Rajshahi', 156),
('RAJSHAHI-2', 'Rajshahi-2', 'Rajshahi', 'Rajshahi', 157),
('RAJSHAHI-3', 'Rajshahi-3', 'Rajshahi', 'Rajshahi', 158),
('RAJSHAHI-4', 'Rajshahi-4', 'Rajshahi', 'Rajshahi', 159),
('RAJSHAHI-5', 'Rajshahi-5', 'Rajshahi', 'Rajshahi', 160),
('RAJSHAHI-6', 'Rajshahi-6', 'Rajshahi', 'Rajshahi', 161),

-- Sirajganj District (6 seats)
('SIRAJGANJ-1', 'Sirajganj-1', 'Sirajganj', 'Rajshahi', 162),
('SIRAJGANJ-2', 'Sirajganj-2', 'Sirajganj', 'Rajshahi', 163),
('SIRAJGANJ-3', 'Sirajganj-3', 'Sirajganj', 'Rajshahi', 164),
('SIRAJGANJ-4', 'Sirajganj-4', 'Sirajganj', 'Rajshahi', 165),
('SIRAJGANJ-5', 'Sirajganj-5', 'Sirajganj', 'Rajshahi', 166),
('SIRAJGANJ-6', 'Sirajganj-6', 'Sirajganj', 'Rajshahi', 167),

-- ========================================
-- KHULNA DIVISION (35 seats)
-- ========================================

-- Bagerhat District (3 seats)
('BAGERHAT-1', 'Bagerhat-1', 'Bagerhat', 'Khulna', 168),
('BAGERHAT-2', 'Bagerhat-2', 'Bagerhat', 'Khulna', 169),
('BAGERHAT-3', 'Bagerhat-3', 'Bagerhat', 'Khulna', 170),

-- Chuadanga District (2 seats)
('CHUADANGA-1', 'Chuadanga-1', 'Chuadanga', 'Khulna', 171),
('CHUADANGA-2', 'Chuadanga-2', 'Chuadanga', 'Khulna', 172),

-- Jashore (Jessore) District (6 seats)
('JASHORE-1', 'Jashore-1', 'Jashore', 'Khulna', 173),
('JASHORE-2', 'Jashore-2', 'Jashore', 'Khulna', 174),
('JASHORE-3', 'Jashore-3', 'Jashore', 'Khulna', 175),
('JASHORE-4', 'Jashore-4', 'Jashore', 'Khulna', 176),
('JASHORE-5', 'Jashore-5', 'Jashore', 'Khulna', 177),
('JASHORE-6', 'Jashore-6', 'Jashore', 'Khulna', 178),

-- Jhenaidah District (4 seats)
('JHENAIDAH-1', 'Jhenaidah-1', 'Jhenaidah', 'Khulna', 179),
('JHENAIDAH-2', 'Jhenaidah-2', 'Jhenaidah', 'Khulna', 180),
('JHENAIDAH-3', 'Jhenaidah-3', 'Jhenaidah', 'Khulna', 181),
('JHENAIDAH-4', 'Jhenaidah-4', 'Jhenaidah', 'Khulna', 182),

-- Khulna District (6 seats)
('KHULNA-1', 'Khulna-1', 'Khulna', 'Khulna', 183),
('KHULNA-2', 'Khulna-2', 'Khulna', 'Khulna', 184),
('KHULNA-3', 'Khulna-3', 'Khulna', 'Khulna', 185),
('KHULNA-4', 'Khulna-4', 'Khulna', 'Khulna', 186),
('KHULNA-5', 'Khulna-5', 'Khulna', 'Khulna', 187),
('KHULNA-6', 'Khulna-6', 'Khulna', 'Khulna', 188),

-- Kushtia District (4 seats)
('KUSHTIA-1', 'Kushtia-1', 'Kushtia', 'Khulna', 189),
('KUSHTIA-2', 'Kushtia-2', 'Kushtia', 'Khulna', 190),
('KUSHTIA-3', 'Kushtia-3', 'Kushtia', 'Khulna', 191),
('KUSHTIA-4', 'Kushtia-4', 'Kushtia', 'Khulna', 192),

-- Magura District (2 seats)
('MAGURA-1', 'Magura-1', 'Magura', 'Khulna', 193),
('MAGURA-2', 'Magura-2', 'Magura', 'Khulna', 194),

-- Meherpur District (1 seat)
('MEHERPUR-1', 'Meherpur-1', 'Meherpur', 'Khulna', 195),

-- Narail District (2 seats)
('NARAIL-1', 'Narail-1', 'Narail', 'Khulna', 196),
('NARAIL-2', 'Narail-2', 'Narail', 'Khulna', 197),

-- Satkhira District (4 seats)
('SATKHIRA-1', 'Satkhira-1', 'Satkhira', 'Khulna', 198),
('SATKHIRA-2', 'Satkhira-2', 'Satkhira', 'Khulna', 199),
('SATKHIRA-3', 'Satkhira-3', 'Satkhira', 'Khulna', 200),
('SATKHIRA-4', 'Satkhira-4', 'Satkhira', 'Khulna', 201),

-- ========================================
-- BARISHAL DIVISION (21 seats)
-- ========================================

-- Barguna District (2 seats)
('BARGUNA-1', 'Barguna-1', 'Barguna', 'Barishal', 202),
('BARGUNA-2', 'Barguna-2', 'Barguna', 'Barishal', 203),

-- Barishal District (6 seats)
('BARISHAL-1', 'Barishal-1', 'Barishal', 'Barishal', 204),
('BARISHAL-2', 'Barishal-2', 'Barishal', 'Barishal', 205),
('BARISHAL-3', 'Barishal-3', 'Barishal', 'Barishal', 206),
('BARISHAL-4', 'Barishal-4', 'Barishal', 'Barishal', 207),
('BARISHAL-5', 'Barishal-5', 'Barishal', 'Barishal', 208),
('BARISHAL-6', 'Barishal-6', 'Barishal', 'Barishal', 209),

-- Bhola District (4 seats)
('BHOLA-1', 'Bhola-1', 'Bhola', 'Barishal', 210),
('BHOLA-2', 'Bhola-2', 'Bhola', 'Barishal', 211),
('BHOLA-3', 'Bhola-3', 'Bhola', 'Barishal', 212),
('BHOLA-4', 'Bhola-4', 'Bhola', 'Barishal', 213),

-- Jhalokathi District (2 seats)
('JHALOKATHI-1', 'Jhalokathi-1', 'Jhalokathi', 'Barishal', 214),
('JHALOKATHI-2', 'Jhalokathi-2', 'Jhalokathi', 'Barishal', 215),

-- Patuakhali District (4 seats)
('PATUAKHALI-1', 'Patuakhali-1', 'Patuakhali', 'Barishal', 216),
('PATUAKHALI-2', 'Patuakhali-2', 'Patuakhali', 'Barishal', 217),
('PATUAKHALI-3', 'Patuakhali-3', 'Patuakhali', 'Barishal', 218),
('PATUAKHALI-4', 'Patuakhali-4', 'Patuakhali', 'Barishal', 219),

-- Pirojpur District (3 seats)
('PIROJPUR-1', 'Pirojpur-1', 'Pirojpur', 'Barishal', 220),
('PIROJPUR-2', 'Pirojpur-2', 'Pirojpur', 'Barishal', 221),
('PIROJPUR-3', 'Pirojpur-3', 'Pirojpur', 'Barishal', 222),

-- ========================================
-- SYLHET DIVISION (19 seats)
-- ========================================

-- Habiganj District (4 seats)
('HABIGANJ-1', 'Habiganj-1', 'Habiganj', 'Sylhet', 223),
('HABIGANJ-2', 'Habiganj-2', 'Habiganj', 'Sylhet', 224),
('HABIGANJ-3', 'Habiganj-3', 'Habiganj', 'Sylhet', 225),
('HABIGANJ-4', 'Habiganj-4', 'Habiganj', 'Sylhet', 226),

-- Moulvibazar District (4 seats)
('MOULVIBAZAR-1', 'Moulvibazar-1', 'Moulvibazar', 'Sylhet', 227),
('MOULVIBAZAR-2', 'Moulvibazar-2', 'Moulvibazar', 'Sylhet', 228),
('MOULVIBAZAR-3', 'Moulvibazar-3', 'Moulvibazar', 'Sylhet', 229),
('MOULVIBAZAR-4', 'Moulvibazar-4', 'Moulvibazar', 'Sylhet', 230),

-- Sunamganj District (5 seats)
('SUNAMGANJ-1', 'Sunamganj-1', 'Sunamganj', 'Sylhet', 231),
('SUNAMGANJ-2', 'Sunamganj-2', 'Sunamganj', 'Sylhet', 232),
('SUNAMGANJ-3', 'Sunamganj-3', 'Sunamganj', 'Sylhet', 233),
('SUNAMGANJ-4', 'Sunamganj-4', 'Sunamganj', 'Sylhet', 234),
('SUNAMGANJ-5', 'Sunamganj-5', 'Sunamganj', 'Sylhet', 235),

-- Sylhet District (6 seats)
('SYLHET-1', 'Sylhet-1', 'Sylhet', 'Sylhet', 236),
('SYLHET-2', 'Sylhet-2', 'Sylhet', 'Sylhet', 237),
('SYLHET-3', 'Sylhet-3', 'Sylhet', 'Sylhet', 238),
('SYLHET-4', 'Sylhet-4', 'Sylhet', 'Sylhet', 239),
('SYLHET-5', 'Sylhet-5', 'Sylhet', 'Sylhet', 240),
('SYLHET-6', 'Sylhet-6', 'Sylhet', 'Sylhet', 241),

-- ========================================
-- RANGPUR DIVISION (33 seats)
-- ========================================

-- Dinajpur District (6 seats)
('DINAJPUR-1', 'Dinajpur-1', 'Dinajpur', 'Rangpur', 242),
('DINAJPUR-2', 'Dinajpur-2', 'Dinajpur', 'Rangpur', 243),
('DINAJPUR-3', 'Dinajpur-3', 'Dinajpur', 'Rangpur', 244),
('DINAJPUR-4', 'Dinajpur-4', 'Dinajpur', 'Rangpur', 245),
('DINAJPUR-5', 'Dinajpur-5', 'Dinajpur', 'Rangpur', 246),
('DINAJPUR-6', 'Dinajpur-6', 'Dinajpur', 'Rangpur', 247),

-- Gaibandha District (5 seats)
('GAIBANDHA-1', 'Gaibandha-1', 'Gaibandha', 'Rangpur', 248),
('GAIBANDHA-2', 'Gaibandha-2', 'Gaibandha', 'Rangpur', 249),
('GAIBANDHA-3', 'Gaibandha-3', 'Gaibandha', 'Rangpur', 250),
('GAIBANDHA-4', 'Gaibandha-4', 'Gaibandha', 'Rangpur', 251),
('GAIBANDHA-5', 'Gaibandha-5', 'Gaibandha', 'Rangpur', 252),

-- Kurigram District (4 seats)
('KURIGRAM-1', 'Kurigram-1', 'Kurigram', 'Rangpur', 253),
('KURIGRAM-2', 'Kurigram-2', 'Kurigram', 'Rangpur', 254),
('KURIGRAM-3', 'Kurigram-3', 'Kurigram', 'Rangpur', 255),
('KURIGRAM-4', 'Kurigram-4', 'Kurigram', 'Rangpur', 256),

-- Lalmonirhat District (3 seats)
('LALMONIRHAT-1', 'Lalmonirhat-1', 'Lalmonirhat', 'Rangpur', 257),
('LALMONIRHAT-2', 'Lalmonirhat-2', 'Lalmonirhat', 'Rangpur', 258),
('LALMONIRHAT-3', 'Lalmonirhat-3', 'Lalmonirhat', 'Rangpur', 259),

-- Nilphamari District (3 seats)
('NILPHAMARI-1', 'Nilphamari-1', 'Nilphamari', 'Rangpur', 260),
('NILPHAMARI-2', 'Nilphamari-2', 'Nilphamari', 'Rangpur', 261),
('NILPHAMARI-3', 'Nilphamari-3', 'Nilphamari', 'Rangpur', 262),

-- Panchagarh District (2 seats)
('PANCHAGARH-1', 'Panchagarh-1', 'Panchagarh', 'Rangpur', 263),
('PANCHAGARH-2', 'Panchagarh-2', 'Panchagarh', 'Rangpur', 264),

-- Rangpur District (6 seats)
('RANGPUR-1', 'Rangpur-1', 'Rangpur', 'Rangpur', 265),
('RANGPUR-2', 'Rangpur-2', 'Rangpur', 'Rangpur', 266),
('RANGPUR-3', 'Rangpur-3', 'Rangpur', 'Rangpur', 267),
('RANGPUR-4', 'Rangpur-4', 'Rangpur', 'Rangpur', 268),
('RANGPUR-5', 'Rangpur-5', 'Rangpur', 'Rangpur', 269),
('RANGPUR-6', 'Rangpur-6', 'Rangpur', 'Rangpur', 270),

-- Thakurgaon District (3 seats)
('THAKURGAON-1', 'Thakurgaon-1', 'Thakurgaon', 'Rangpur', 271),
('THAKURGAON-2', 'Thakurgaon-2', 'Thakurgaon', 'Rangpur', 272),
('THAKURGAON-3', 'Thakurgaon-3', 'Thakurgaon', 'Rangpur', 273),

-- ========================================
-- MYMENSINGH DIVISION (24 seats)
-- ========================================

-- Jamalpur District (5 seats)
('JAMALPUR-1', 'Jamalpur-1', 'Jamalpur', 'Mymensingh', 274),
('JAMALPUR-2', 'Jamalpur-2', 'Jamalpur', 'Mymensingh', 275),
('JAMALPUR-3', 'Jamalpur-3', 'Jamalpur', 'Mymensingh', 276),
('JAMALPUR-4', 'Jamalpur-4', 'Jamalpur', 'Mymensingh', 277),
('JAMALPUR-5', 'Jamalpur-5', 'Jamalpur', 'Mymensingh', 278),

-- Mymensingh District (11 seats)
('MYMENSINGH-1', 'Mymensingh-1', 'Mymensingh', 'Mymensingh', 279),
('MYMENSINGH-2', 'Mymensingh-2', 'Mymensingh', 'Mymensingh', 280),
('MYMENSINGH-3', 'Mymensingh-3', 'Mymensingh', 'Mymensingh', 281),
('MYMENSINGH-4', 'Mymensingh-4', 'Mymensingh', 'Mymensingh', 282),
('MYMENSINGH-5', 'Mymensingh-5', 'Mymensingh', 'Mymensingh', 283),
('MYMENSINGH-6', 'Mymensingh-6', 'Mymensingh', 'Mymensingh', 284),
('MYMENSINGH-7', 'Mymensingh-7', 'Mymensingh', 'Mymensingh', 285),
('MYMENSINGH-8', 'Mymensingh-8', 'Mymensingh', 'Mymensingh', 286),
('MYMENSINGH-9', 'Mymensingh-9', 'Mymensingh', 'Mymensingh', 287),
('MYMENSINGH-10', 'Mymensingh-10', 'Mymensingh', 'Mymensingh', 288),
('MYMENSINGH-11', 'Mymensingh-11', 'Mymensingh', 'Mymensingh', 289),

-- Netrokona District (5 seats)
('NETROKONA-1', 'Netrokona-1', 'Netrokona', 'Mymensingh', 290),
('NETROKONA-2', 'Netrokona-2', 'Netrokona', 'Mymensingh', 291),
('NETROKONA-3', 'Netrokona-3', 'Netrokona', 'Mymensingh', 292),
('NETROKONA-4', 'Netrokona-4', 'Netrokona', 'Mymensingh', 293),
('NETROKONA-5', 'Netrokona-5', 'Netrokona', 'Mymensingh', 294),

-- Sherpur District (3 seats)
('SHERPUR-1', 'Sherpur-1', 'Sherpur', 'Mymensingh', 295),
('SHERPUR-2', 'Sherpur-2', 'Sherpur', 'Mymensingh', 296),
('SHERPUR-3', 'Sherpur-3', 'Sherpur', 'Mymensingh', 297);

-- ========================================
-- RESERVED SEATS (50 for Women)
-- ========================================
-- Note: Reserved seats are filled through proportional representation
-- based on seats won by parties in general elections.
-- These are not directly elected constituencies.

INSERT INTO constituencies (constituency_code, constituency_name, district, division, seat_number) VALUES
('RESERVED-1', 'Reserved Seat for Women-1', 'National', 'National', 301),
('RESERVED-2', 'Reserved Seat for Women-2', 'National', 'National', 302),
('RESERVED-3', 'Reserved Seat for Women-3', 'National', 'National', 303);

-- Summary Statistics
-- Total: 300 directly elected + 50 reserved = 350 seats
-- This dataset includes all 300 directly elected constituencies

SELECT 
    division,
    COUNT(*) as total_seats
FROM constituencies
WHERE division != 'National'
GROUP BY division
ORDER BY total_seats DESC;
