# Complete Full-Stack Setup Script
# Shadhin Vote Monitor - Automated Database Setup

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Shadhin Vote Monitor" -ForegroundColor Cyan
Write-Host "  Full-Stack Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Step 1: Check Docker
Write-Host "Step 1: Checking Docker..." -ForegroundColor Yellow
try {
    docker --version | Out-Null
    Write-Host "✓ Docker is installed" -ForegroundColor Green
}
catch {
    Write-Host "✗ Docker is not installed" -ForegroundColor Red
    Write-Host "  Please install Docker Desktop from: https://www.docker.com/products/docker-desktop" -ForegroundColor Yellow
    exit 1
}

# Step 2: Check if database is running
Write-Host ""
Write-Host "Step 2: Starting PostgreSQL database..." -ForegroundColor Yellow
$dbRunning = docker ps --filter "name=shadhin-vote-db" --format "{{.Names}}"
if ($dbRunning -eq "shadhin-vote-db") {
    Write-Host "✓ Database is already running" -ForegroundColor Green
}
else {
    Write-Host "  Starting database container..." -ForegroundColor Yellow
    docker-compose up -d postgres
    Start-Sleep -Seconds 5
    Write-Host "✓ Database started" -ForegroundColor Green
}

# Step 3: Wait for database to be ready
Write-Host ""
Write-Host "Step 3: Waiting for database to be ready..." -ForegroundColor Yellow
$maxAttempts = 30
$attempt = 0
$dbReady = $false

while ($attempt -lt $maxAttempts -and -not $dbReady) {
    $attempt++
    try {
        $result = docker exec shadhin-vote-db pg_isready -U postgres 2>&1
        if ($result -match "accepting connections") {
            $dbReady = $true
            Write-Host "✓ Database is ready" -ForegroundColor Green
        }
        else {
            Write-Host "  Waiting... ($attempt/$maxAttempts)" -ForegroundColor Gray
            Start-Sleep -Seconds 1
        }
    }
    catch {
        Write-Host "  Waiting... ($attempt/$maxAttempts)" -ForegroundColor Gray
        Start-Sleep -Seconds 1
    }
}

if (-not $dbReady) {
    Write-Host "✗ Database failed to start" -ForegroundColor Red
    exit 1
}

# Step 4: Import schema
Write-Host ""
Write-Host "Step 4: Importing database schema..." -ForegroundColor Yellow
try {
    docker exec -i shadhin-vote-db psql -U postgres -d election_monitor -f /docker-entrypoint-initdb.d/schema.sql 2>&1 | Out-Null
    Write-Host "✓ Schema imported successfully" -ForegroundColor Green
}
catch {
    Write-Host "  Schema may already exist (this is OK)" -ForegroundColor Yellow
}

# Step 5: Import constituencies
Write-Host ""
Write-Host "Step 5: Importing constituency data (300 seats)..." -ForegroundColor Yellow
try {
    docker cp database/constituencies.sql shadhin-vote-db:/tmp/constituencies.sql
    docker exec -i shadhin-vote-db psql -U postgres -d election_monitor -f /tmp/constituencies.sql 2>&1 | Out-Null
    Write-Host "✓ Constituencies imported successfully" -ForegroundColor Green
}
catch {
    Write-Host "  Constituencies may already exist (this is OK)" -ForegroundColor Yellow
}

# Step 6: Verify tables
Write-Host ""
Write-Host "Step 6: Verifying database tables..." -ForegroundColor Yellow
$tables = docker exec shadhin-vote-db psql -U postgres -d election_monitor -c "\dt" 2>&1
if ($tables -match "reports" -and $tables -match "constituencies") {
    Write-Host "✓ All tables created successfully" -ForegroundColor Green
    Write-Host "  Tables: reports, constituencies, admins, rate_limits, audit_logs" -ForegroundColor Gray
}
else {
    Write-Host "✗ Some tables may be missing" -ForegroundColor Red
}

# Step 7: Check constituency count
Write-Host ""
Write-Host "Step 7: Verifying constituency data..." -ForegroundColor Yellow
$count = docker exec shadhin-vote-db psql -U postgres -d election_monitor -t -c "SELECT COUNT(*) FROM constituencies;" 2>&1
$count = $count.Trim()
if ($count -eq "300") {
    Write-Host "✓ All 300 constituencies loaded" -ForegroundColor Green
}
else {
    Write-Host "  Found $count constituencies" -ForegroundColor Yellow
}

# Step 8: Install Node dependencies
Write-Host ""
Write-Host "Step 8: Installing Node.js dependencies..." -ForegroundColor Yellow
if (Test-Path "node_modules") {
    Write-Host "  node_modules exists, checking for updates..." -ForegroundColor Gray
}
npm install --silent
Write-Host "✓ Dependencies installed" -ForegroundColor Green

# Step 9: Check environment file
Write-Host ""
Write-Host "Step 9: Checking environment configuration..." -ForegroundColor Yellow
if (Test-Path ".env") {
    Write-Host "✓ .env file exists" -ForegroundColor Green
}
else {
    Write-Host "  Creating .env from .env.example..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host "✓ .env file created" -ForegroundColor Green
    Write-Host "  ⚠️  Please update .env with your credentials" -ForegroundColor Yellow
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete! ✓" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Database Information:" -ForegroundColor Cyan
Write-Host "  Host: localhost" -ForegroundColor White
Write-Host "  Port: 5432" -ForegroundColor White
Write-Host "  Database: election_monitor" -ForegroundColor White
Write-Host "  User: postgres" -ForegroundColor White
Write-Host "  Password: postgres" -ForegroundColor White
Write-Host ""
Write-Host "Data Loaded:" -ForegroundColor Cyan
Write-Host "  ✓ Database schema" -ForegroundColor White
Write-Host "  ✓ 300 constituencies (all 64 districts)" -ForegroundColor White
Write-Host "  ✓ Admin tables" -ForegroundColor White
Write-Host "  ✓ Rate limiting tables" -ForegroundColor White
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Start the application:" -ForegroundColor White
Write-Host "     npm run dev" -ForegroundColor Yellow
Write-Host ""
Write-Host "  2. Open in browser:" -ForegroundColor White
Write-Host "     http://localhost:3000" -ForegroundColor Yellow
Write-Host ""
Write-Host "  3. Test the application:" -ForegroundColor White
Write-Host "     - Submit a test report" -ForegroundColor Gray
Write-Host "     - Upload a photo/video" -ForegroundColor Gray
Write-Host "     - View in live feed" -ForegroundColor Gray
Write-Host ""
Write-Host "  4. Access database:" -ForegroundColor White
Write-Host "     docker exec -it shadhin-vote-db psql -U postgres -d election_monitor" -ForegroundColor Yellow
Write-Host ""
Write-Host "Documentation:" -ForegroundColor Cyan
Write-Host "  - FULLSTACK_SETUP.md - Complete setup guide" -ForegroundColor White
Write-Host "  - API.md - API documentation" -ForegroundColor White
Write-Host "  - DEPLOYMENT.md - Deployment guide" -ForegroundColor White
Write-Host ""
Write-Host "Support:" -ForegroundColor Cyan
Write-Host "  - Check logs: docker-compose logs -f" -ForegroundColor White
Write-Host "  - Stop database: docker-compose down" -ForegroundColor White
Write-Host "  - Restart: docker-compose restart" -ForegroundColor White
Write-Host ""
Write-Host "Ready to go! 🚀" -ForegroundColor Green
Write-Host ""
