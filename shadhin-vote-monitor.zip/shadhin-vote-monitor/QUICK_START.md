# ⚡ QUICK START - 30 Seconds to Running App!

## 🚀 Three Commands to Success

```powershell
# 1. Setup (one time only)
.\setup-fullstack.ps1

# 2. Start
npm run dev

# 3. Open
http://localhost:3000
```

## ✅ What's Included

- ✅ PostgreSQL Database (Docker)
- ✅ 300 Constituencies Loaded
- ✅ All 64 Districts
- ✅ File Upload (UploadThing)
- ✅ Video/Image Display
- ✅ Live Feed
- ✅ Admin Panel

## 📊 Database

```
Host: localhost:5432
DB: election_monitor
User: postgres
Pass: postgres
```

## 🔗 Quick Links

- **App**: http://localhost:3000
- **API**: http://localhost:3000/api/reports/list
- **Admin**: http://localhost:3000/admin/login
- **UploadThing**: https://uploadthing.com/dashboard/hg8xtvziiv

## 🧪 Quick Test

1. Select "Dhaka" district
2. Select "DHAKA-1" constituency  
3. Upload test image
4. Submit report
5. Check feed!

## 🐳 Docker Commands

```powershell
# Start database
docker-compose up -d postgres

# Stop all
docker-compose down

# View logs
docker-compose logs -f

# Access DB
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor
```

## 📚 Documentation

- `START_HERE.md` - Complete guide
- `FULLSTACK_SETUP.md` - Detailed setup
- `TESTING_GUIDE.md` - How to test
- `API.md` - API docs

## 🐛 Troubleshooting

```powershell
# Database won't start?
docker-compose restart postgres

# Port 3000 in use?
$env:PORT=3001
npm run dev

# Constituencies missing?
.\setup-fullstack.ps1
```

## 🎯 Features

✅ 64 Districts
✅ 300 Constituencies  
✅ Image Upload (JPG, PNG)
✅ Video Upload (MP4)
✅ Live Feed
✅ Video Playback
✅ District Filtering
✅ Anonymous Tracking
✅ Rate Limiting
✅ Admin Panel

## 📦 Tech Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Next.js, Node.js
- **Database**: PostgreSQL
- **Storage**: UploadThing
- **Container**: Docker

---

**That's it! You're ready to go! 🎉**

Need help? Check `START_HERE.md` for complete guide!
