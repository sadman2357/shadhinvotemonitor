{
    "i18n": {
        "defaultLocale": "bn",
            "locales": ["bn", "en"]
    },
    "localePath": "./public/locales"
}
