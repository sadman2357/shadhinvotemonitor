# UploadThing Integration Guide

## Overview
UploadThing is now configured for secure, anonymous file uploads in the Shadhin Vote Monitor platform.

## Configuration Complete ✅

### 1. Environment Variables Added
Your UploadThing credentials have been configured in `.env`:

```bash
UPLOADTHING_TOKEN=eyJhcGlLZXkiOiJza19saXZlXzZkMzE2ODA2ZDIxMzc5MmFjMjFmY2QwZTAwODkzMWZiM2VjMmFlMWYxODk4M2QzMjMzOWRmMTg3YTE2ZTgzNTgiLCJhcHBJZCI6ImhnOHh0dnppaXYiLCJyZWdpb25zIjpbInNlYTEiXX0=
UPLOADTHING_SECRET=sk_live_6d316806d213792ac21fcd0e008931fb3ec2ae1f18983d32339df187a16e8358
UPLOADTHING_APP_ID=hg8xtvziiv
```

### 2. Files Created

#### `lib/uploadthing.ts`
- File router configuration
- Middleware for IP hashing (anonymous tracking)
- Upload completion handler
- Supports images (JPG, PNG) and videos (MP4)
- Max file size: 20MB

#### `pages/api/uploadthing.ts`
- API route handler for UploadThing
- Endpoint: `/api/uploadthing`

### 3. Dependencies Added to package.json
```json
"uploadthing": "^6.13.2",
"@uploadthing/react": "^6.7.2"
```

## Installation Steps

### 1. Install Dependencies
```bash
npm install
```

This will install:
- `uploadthing` - Core UploadThing SDK
- `@uploadthing/react` - React components for file uploads

### 2. Verify Environment Variables
Make sure `.env` file exists with your UploadThing credentials.

### 3. Start Development Server
```bash
npm run dev
```

## How It Works

### Upload Flow
1. **User selects file** in the report form
2. **File is validated** (type, size)
3. **Uploaded to UploadThing** via `/api/uploadthing`
4. **IP is hashed** (SHA-256) for anonymous tracking
5. **File URL returned** and stored in database
6. **Report submitted** with file URL

### Security Features
✅ **Anonymous uploads** - No personal data stored
✅ **IP hashing** - IPs are hashed, never stored in plain text
✅ **File validation** - Type and size checks
✅ **Rate limiting** - Prevents abuse
✅ **Secure storage** - Files stored on UploadThing's CDN

## File Upload Limits

| Type | Max Size | Formats |
|------|----------|---------|
| Images | 20MB | JPG, PNG |
| Videos | 20MB | MP4 |

## API Endpoints

### Upload Endpoint
```
POST /api/uploadthing
```

**Request:** Multipart form data with file
**Response:**
```json
{
  "uploadedBy": "hashed-ip",
  "fileUrl": "https://uploadthing.com/f/...",
  "fileName": "evidence.jpg",
  "fileSize": 1048576,
  "fileType": "image/jpeg"
}
```

## Integration with Report Submission

The file upload is integrated into the report submission flow:

1. User fills out report form
2. Selects district and constituency
3. **Uploads photo/video evidence**
4. File is uploaded to UploadThing
5. File URL is included in report submission
6. Report is stored in database with file reference

## Testing

### Test File Upload
1. Open the application: `http://localhost:3000`
2. Navigate to report form
3. Select a district and constituency
4. Choose a file (image or video, max 20MB)
5. Submit the form
6. Check console for upload confirmation

### Verify Upload
- Check UploadThing dashboard: https://uploadthing.com/dashboard
- View uploaded files in your app: `hg8xtvziiv`
- Files are stored in SEA1 region (Southeast Asia)

## UploadThing Dashboard

Access your dashboard at: https://uploadthing.com/dashboard/hg8xtvziiv

Features:
- View all uploaded files
- Monitor storage usage
- Check upload analytics
- Manage file retention policies

## Storage & Pricing

### Your Plan
- **App ID:** hg8xtvziiv
- **Region:** SEA1 (Southeast Asia - Singapore)
- **Storage:** Check dashboard for current usage

### File Retention
Files are stored permanently by default. You can configure retention policies in the UploadThing dashboard.

## Advantages Over AWS S3

✅ **Easier Setup** - No complex AWS configuration
✅ **Better DX** - Simple API, great documentation
✅ **Built-in CDN** - Fast global delivery
✅ **Automatic Optimization** - Images are optimized automatically
✅ **Type Safety** - Full TypeScript support
✅ **Free Tier** - Generous free tier for development

## Migration from S3 (Optional)

If you want to keep using S3, you can:
1. Keep the existing S3 configuration in `.env`
2. Use UploadThing for development
3. Switch to S3 for production

Both systems can coexist.

## Troubleshooting

### Upload Fails
- Check `.env` file has correct credentials
- Verify file size is under 20MB
- Ensure file type is JPG, PNG, or MP4
- Check console for error messages

### API Route Not Found
- Ensure `pages/api/uploadthing.ts` exists
- Restart development server
- Check Next.js is running on port 3000

### TypeScript Errors
- Run `npm install` to install dependencies
- Restart your IDE/editor
- Check `tsconfig.json` is properly configured

## Next Steps

1. **Install dependencies:** `npm install`
2. **Test upload:** Try uploading a file through the form
3. **Check dashboard:** Verify files appear in UploadThing dashboard
4. **Update report API:** Integrate file URLs into report submission

## Support

- **UploadThing Docs:** https://docs.uploadthing.com
- **Dashboard:** https://uploadthing.com/dashboard
- **Discord:** https://discord.gg/uploadthing

---

**Status:** ✅ UploadThing is configured and ready to use!

**App ID:** hg8xtvziiv  
**Region:** SEA1 (Singapore)  
**Max File Size:** 20MB  
**Supported Formats:** JPG, PNG, MP4
