# 🚀 Complete Full-Stack Setup Guide
## Shadhin Vote Monitor - Database Connection & Deployment

This guide will help you set up the complete full-stack application with database connectivity.

---

## 📋 Prerequisites

Before starting, ensure you have:
- ✅ Node.js 18+ installed
- ✅ Docker Desktop installed (for local database)
- ✅ Git installed
- ✅ A code editor (VS Code recommended)

---

## 🗄️ Database Setup

### Option 1: Local PostgreSQL with Docker (Recommended for Development)

#### Step 1: Start PostgreSQL Container
```powershell
# Navigate to project directory
cd c:\Users\user\.gemini\antigravity\scratch\shadhin-vote-monitor

# Start PostgreSQL using Docker Compose
docker-compose up -d postgres
```

#### Step 2: Verify Database is Running
```powershell
# Check container status
docker ps

# Should see: shadhin-vote-db running on port 5432
```

#### Step 3: Import Database Schema
```powershell
# Import schema (creates tables)
docker exec -i shadhin-vote-db psql -U postgres -d election_monitor -f /docker-entrypoint-initdb.d/schema.sql

# Import constituency data (300 constituencies)
docker cp database/constituencies.sql shadhin-vote-db:/tmp/constituencies.sql
docker exec -i shadhin-vote-db psql -U postgres -d election_monitor -f /tmp/constituencies.sql
```

#### Step 4: Verify Tables Created
```powershell
# Connect to database
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor

# List tables
\dt

# Should see:
# - reports
# - constituencies
# - admins
# - rate_limits
# - audit_logs

# Exit
\q
```

### Option 2: Cloud PostgreSQL (Recommended for Production)

#### Vercel Postgres
```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Create Postgres database
vercel postgres create

# Get connection string
vercel env pull .env.local
```

#### Supabase
1. Go to https://supabase.com
2. Create new project
3. Copy connection string
4. Update `.env` file

#### Neon
1. Go to https://neon.tech
2. Create new project
3. Copy connection string
4. Update `.env` file

---

## 🔧 Environment Configuration

### Step 1: Update .env File
```bash
# Database Configuration
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/election_monitor
DB_HOST=localhost
DB_PORT=5432
DB_NAME=election_monitor
DB_USER=postgres
DB_PASSWORD=postgres

# JWT Secret
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production-2026

# UploadThing Configuration
UPLOADTHING_TOKEN=eyJhcGlLZXkiOiJza19saXZlXzZkMzE2ODA2ZDIxMzc5MmFjMjFmY2QwZTAwODkzMWZiM2VjMmFlMWYxODk4M2QzMjMzOWRmMTg3YTE2ZTgzNTgiLCJhcHBJZCI6ImhnOHh0dnppaXYiLCJyZWdpb25zIjpbInNlYTEiXX0=
UPLOADTHING_SECRET=sk_live_6d316806d213792ac21fcd0e008931fb3ec2ae1f18983d32339df187a16e8358
UPLOADTHING_APP_ID=hg8xtvziiv

# Application Configuration
NODE_ENV=development
NEXT_PUBLIC_API_URL=http://localhost:3000
PORT=3000

# Rate Limiting
RATE_LIMIT_WINDOW_MS=3600000
RATE_LIMIT_MAX_REQUESTS=3

# File Upload Limits
MAX_FILE_SIZE=20971520
ALLOWED_IMAGE_TYPES=image/jpeg,image/png
ALLOWED_VIDEO_TYPES=video/mp4

# Security
ALLOWED_ORIGINS=http://localhost:3000
ENABLE_HTTPS_ONLY=false

# Admin Configuration (Change these!)
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=$2a$10$YourBcryptHashHere
```

---

## 📦 Install Dependencies

```powershell
# Install all Node.js dependencies
npm install

# This installs:
# - Next.js framework
# - PostgreSQL client (pg)
# - UploadThing for file uploads
# - Security libraries
# - And more...
```

---

## 🏗️ Database Schema Overview

### Tables Created

#### 1. **reports** (Main table for incident reports)
```sql
- id (Primary Key)
- district
- constituency
- voting_center_number
- description
- media_url (UploadThing URL)
- media_type (image/jpeg, video/mp4)
- media_thumbnail_url
- file_size_bytes
- file_hash (for duplicate detection)
- ip_hash (anonymized IP)
- gps_latitude
- gps_longitude
- status (under_review, verified, rejected)
- created_at
- updated_at
```

#### 2. **constituencies** (All 300 Bangladesh constituencies)
```sql
- id (Primary Key)
- constituency_code (e.g., DHAKA-1)
- constituency_name
- district
- division
- seat_number
- created_at
```

#### 3. **admins** (Admin users)
```sql
- id (Primary Key)
- username
- password_hash
- email
- role
- created_at
- last_login
```

#### 4. **rate_limits** (Rate limiting for submissions)
```sql
- id (Primary Key)
- ip_hash
- request_count
- window_start
- created_at
```

#### 5. **audit_logs** (Activity tracking)
```sql
- id (Primary Key)
- action
- resource_type
- resource_id
- user_id
- ip_hash
- details (JSON)
- created_at
```

---

## 🚀 Start the Application

### Development Mode
```powershell
# Start Next.js development server
npm run dev

# Application will be available at:
# http://localhost:3000
```

### Production Mode
```powershell
# Build the application
npm run build

# Start production server
npm start
```

### Using Docker Compose (Full Stack)
```powershell
# Start everything (database + app + nginx)
docker-compose up -d

# View logs
docker-compose logs -f

# Stop everything
docker-compose down
```

---

## ✅ Verify Everything Works

### 1. Check Database Connection
```powershell
# Start the app
npm run dev

# You should see in console:
# ✓ Database connected successfully
```

### 2. Test API Endpoints

#### Get Constituencies
```bash
# Open browser or use curl
http://localhost:3000/api/constituencies?district=Dhaka

# Should return 20 constituencies
```

#### Get Reports
```bash
http://localhost:3000/api/reports/list?status=verified

# Should return empty array (no reports yet)
```

### 3. Submit a Test Report
1. Open http://localhost:3000
2. Fill out the report form:
   - Select district: "Dhaka"
   - Select constituency: "DHAKA-1"
   - Enter voting center: "VC-123"
   - Upload a test image/video
   - Add description (optional)
3. Submit the form
4. Check database:
```powershell
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor -c "SELECT * FROM reports;"
```

### 4. View Report in Feed
1. Scroll to "Live Reports" section
2. Your report should appear (after admin verification)
3. Video/image should be visible and playable

---

## 🔐 Admin Setup

### Create Admin User
```powershell
# Connect to database
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor

# Create admin (password: admin123)
INSERT INTO admins (username, password_hash, email, role)
VALUES (
  'admin',
  '$2a$10$rOvHXvZvZvZvZvZvZvZvZuXXXXXXXXXXXXXXXXXXXXXXXX',
  'admin@example.com',
  'super_admin'
);

# Exit
\q
```

### Access Admin Panel
```
http://localhost:3000/admin/login
Username: admin
Password: admin123
```

---

## 📊 Database Management

### View All Reports
```sql
SELECT 
  id,
  constituency,
  status,
  media_type,
  created_at
FROM reports
ORDER BY created_at DESC
LIMIT 10;
```

### View All Constituencies
```sql
SELECT 
  constituency_code,
  constituency_name,
  district,
  division
FROM constituencies
WHERE district = 'Dhaka'
ORDER BY seat_number;
```

### Update Report Status
```sql
UPDATE reports
SET status = 'verified'
WHERE id = 1;
```

### View Statistics
```sql
-- Total reports by district
SELECT district, COUNT(*) as total
FROM reports
GROUP BY district
ORDER BY total DESC;

-- Reports by status
SELECT status, COUNT(*) as total
FROM reports
GROUP BY status;
```

---

## 🐛 Troubleshooting

### Database Connection Failed
```powershell
# Check if PostgreSQL is running
docker ps | findstr shadhin-vote-db

# Restart database
docker-compose restart postgres

# Check logs
docker-compose logs postgres
```

### Port Already in Use
```powershell
# Find process using port 3000
netstat -ano | findstr :3000

# Kill process (replace PID)
taskkill /PID <PID> /F

# Or use different port
$env:PORT=3001
npm run dev
```

### UploadThing Upload Fails
- Check `.env` has correct `UPLOADTHING_TOKEN`
- Verify file size is under 20MB
- Check file type is JPG, PNG, or MP4
- Check console for error messages

### Reports Not Showing in Feed
- Check database has reports: `SELECT * FROM reports;`
- Verify status is 'verified'
- Check browser console for errors
- Verify API endpoint works: `/api/reports/list`

---

## 🌐 Deployment Options

### Option 1: Vercel (Recommended)
```powershell
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Add environment variables in Vercel dashboard
# Add Vercel Postgres database
```

### Option 2: Docker (VPS/Cloud)
```powershell
# Build and deploy
docker-compose up -d

# Use nginx for SSL/HTTPS
```

### Option 3: Traditional Hosting
```powershell
# Build
npm run build

# Copy .next folder to server
# Run: npm start
```

---

## 📁 Project Structure

```
shadhin-vote-monitor/
├── database/
│   ├── schema.sql          # Database schema
│   ├── constituencies.sql  # 300 constituencies data
│   └── seed.sql           # Sample data
├── lib/
│   ├── db.js              # Database connection
│   ├── uploadthing.ts     # File upload config
│   ├── security.js        # Security utilities
│   └── storage.js         # File storage
├── pages/
│   ├── api/
│   │   ├── constituencies.js  # Get constituencies
│   │   ├── reports/
│   │   │   ├── submit.js      # Submit report
│   │   │   └── list.js        # List reports
│   │   └── uploadthing.ts     # File upload endpoint
│   └── admin/             # Admin panel
├── index-standalone.html  # Main frontend
├── .env                   # Environment variables
├── docker-compose.yml     # Docker configuration
└── package.json          # Dependencies
```

---

## ✅ Checklist

### Database Setup
- [ ] PostgreSQL running (Docker or cloud)
- [ ] Schema imported
- [ ] Constituencies imported (300 seats)
- [ ] Database connection verified

### Application Setup
- [ ] Dependencies installed (`npm install`)
- [ ] `.env` file configured
- [ ] UploadThing credentials added
- [ ] Application starts (`npm run dev`)

### Features Working
- [ ] Homepage loads
- [ ] District dropdown shows all 64 districts
- [ ] Constituency dropdown populates dynamically
- [ ] File upload works
- [ ] Report submission successful
- [ ] Reports appear in feed
- [ ] Videos/images display correctly

### Admin Panel
- [ ] Admin user created
- [ ] Can login to admin panel
- [ ] Can verify/reject reports

---

## 🎉 You're All Set!

Your full-stack Shadhin Vote Monitor is now complete and connected to the database!

### Next Steps:
1. **Test thoroughly** - Submit test reports
2. **Customize** - Update branding, colors, text
3. **Deploy** - Choose Vercel, Docker, or VPS
4. **Monitor** - Check logs and database regularly
5. **Secure** - Change default passwords, add SSL

### Support:
- Documentation: See all `.md` files in project
- Database: Check `database/` folder
- API: See `API.md`
- Deployment: See `DEPLOYMENT.md`

**Happy monitoring! 🗳️✨**
