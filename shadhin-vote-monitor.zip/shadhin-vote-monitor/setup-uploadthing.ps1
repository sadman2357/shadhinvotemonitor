# UploadThing Quick Setup Script
# Run this to install and configure UploadThing

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Shadhin Vote Monitor - UploadThing Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if .env exists
if (Test-Path ".env") {
    Write-Host "✓ .env file found" -ForegroundColor Green
} else {
    Write-Host "✗ .env file not found" -ForegroundColor Red
    Write-Host "  Creating .env from .env.example..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host "✓ .env file created" -ForegroundColor Green
}

Write-Host ""
Write-Host "Installing dependencies..." -ForegroundColor Yellow
npm install

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "UploadThing Configuration:" -ForegroundColor Cyan
Write-Host "  App ID: hg8xtvziiv" -ForegroundColor White
Write-Host "  Region: SEA1 (Singapore)" -ForegroundColor White
Write-Host "  Max File Size: 20MB" -ForegroundColor White
Write-Host "  Formats: JPG, PNG, MP4" -ForegroundColor White
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Run 'npm run dev' to start the server" -ForegroundColor White
Write-Host "  2. Visit http://localhost:3000" -ForegroundColor White
Write-Host "  3. Test file upload in the report form" -ForegroundColor White
Write-Host "  4. Check uploads at: https://uploadthing.com/dashboard" -ForegroundColor White
Write-Host ""
Write-Host "Documentation: See UPLOADTHING_SETUP.md" -ForegroundColor Yellow
Write-Host ""
