# 🚀 Quick Reference - UploadThing Integration

## Installation
```bash
npm install
npm run dev
```

## Your Credentials
```
App ID:  hg8xtvziiv
Region:  SEA1 (Singapore)
Token:   ✅ Configured in .env
```

## Dashboard
https://uploadthing.com/dashboard/hg8xtvziiv

## File Limits
- **Max Size**: 20MB
- **Formats**: JPG, PNG, MP4

## API Endpoint
```
POST /api/uploadthing
```

## Files Created
- ✅ `.env` - Your credentials
- ✅ `lib/uploadthing.ts` - File router
- ✅ `pages/api/uploadthing.ts` - API handler
- ✅ `package.json` - Updated dependencies

## Test Upload
1. `npm run dev`
2. Open http://localhost:3000
3. Fill report form
4. Upload a file
5. Check dashboard

## Documentation
- `UPLOADTHING_SUMMARY.md` - Complete overview
- `UPLOADTHING_SETUP.md` - Detailed guide
- `CONSTITUENCY_DATA.md` - Electoral data

## Support
- Docs: https://docs.uploadthing.com
- Discord: https://discord.gg/uploadthing

---
**Status**: ✅ Ready to use!
