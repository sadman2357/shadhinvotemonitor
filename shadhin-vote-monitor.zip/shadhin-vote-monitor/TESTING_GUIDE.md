# 🧪 Complete Testing Guide
## Shadhin Vote Monitor - Full-Stack Testing

This guide will help you test all features of the application to ensure everything is working correctly.

---

## 🚀 Quick Start Testing

### Step 1: Run the Setup Script
```powershell
.\setup-fullstack.ps1
```

This will:
- ✅ Start PostgreSQL database
- ✅ Import schema and data
- ✅ Install dependencies
- ✅ Verify everything is ready

### Step 2: Start the Application
```powershell
npm run dev
```

### Step 3: Open in Browser
```
http://localhost:3000
```

---

## ✅ Feature Testing Checklist

### 1. Homepage & UI

#### Test: Page Loads
- [ ] Homepage loads without errors
- [ ] All sections visible (Hero, Report Form, Live Reports, About)
- [ ] Language toggle works (Bengali ⇄ English)
- [ ] Mobile menu works on small screens
- [ ] Smooth scrolling works for anchor links

#### Test: Responsive Design
- [ ] Desktop view (1920x1080)
- [ ] Tablet view (768x1024)
- [ ] Mobile view (375x667)
- [ ] All elements properly aligned
- [ ] No horizontal scrolling

---

### 2. District & Constituency Selection

#### Test: District Dropdown
- [ ] Dropdown shows all 64 districts
- [ ] Districts grouped by division (8 divisions)
- [ ] Both English and Bengali names shown
- [ ] Can select any district

**Test Districts:**
```
✓ Dhaka (ঢাকা)
✓ Chattogram (চট্টগ্রাম)
✓ Sylhet (সিলেট)
✓ Mymensingh (ময়মনসিংহ)
```

#### Test: Constituency Dropdown
- [ ] Disabled until district selected
- [ ] Populates when district selected
- [ ] Shows correct constituencies for district

**Test Cases:**
```javascript
// Select "Dhaka" → Should show 20 constituencies
DHAKA-1, DHAKA-2, ..., DHAKA-20

// Select "Mymensingh" → Should show 11 constituencies
MYMENSINGH-1, MYMENSINGH-2, ..., MYMENSINGH-11

// Select "Bandarban" → Should show 1 constituency
BANDARBAN-1
```

#### Verify API Call
```bash
# Open browser console (F12)
# Select a district
# Should see API call:
GET /api/constituencies?district=Dhaka

# Or test directly:
curl http://localhost:3000/api/constituencies?district=Dhaka
```

---

### 3. File Upload (UploadThing)

#### Test: Image Upload
- [ ] Can select JPG file
- [ ] Can select PNG file
- [ ] File size validation (max 20MB)
- [ ] File name displays after selection
- [ ] Invalid file types rejected

**Test Files:**
```
✓ test-image.jpg (under 20MB)
✓ test-image.png (under 20MB)
✗ test-file.pdf (should reject)
✗ large-file.jpg (over 20MB - should reject)
```

#### Test: Video Upload
- [ ] Can select MP4 file
- [ ] File size validation (max 20MB)
- [ ] Invalid formats rejected

**Test Files:**
```
✓ test-video.mp4 (under 20MB)
✗ test-video.avi (should reject)
✗ large-video.mp4 (over 20MB - should reject)
```

#### Verify Upload
```bash
# After uploading, check UploadThing dashboard:
https://uploadthing.com/dashboard/hg8xtvziiv

# Should see uploaded file
```

---

### 4. Report Submission

#### Test: Form Validation
- [ ] Cannot submit without district
- [ ] Cannot submit without constituency
- [ ] Cannot submit without voting center
- [ ] Cannot submit without file
- [ ] Error messages display correctly

#### Test: Successful Submission
1. Fill out form:
   - District: "Dhaka"
   - Constituency: "DHAKA-1"
   - Voting Center: "VC-123"
   - Description: "Test report"
   - File: Upload test image

2. Submit form

3. Verify:
   - [ ] Success message appears
   - [ ] Form resets
   - [ ] File upload cleared

#### Verify in Database
```powershell
# Connect to database
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor

# Check report was saved
SELECT id, constituency, media_url, status FROM reports ORDER BY created_at DESC LIMIT 1;

# Should see your test report
# Exit
\q
```

---

### 5. Live Reports Feed

#### Test: Reports Display
- [ ] Feed section loads
- [ ] Filter dropdown works
- [ ] Reports display in grid layout
- [ ] Each report shows:
  - [ ] Media (image or video)
  - [ ] Constituency name
  - [ ] Status badge
  - [ ] Time ago

#### Test: Image Display
- [ ] Images load correctly
- [ ] Proper aspect ratio maintained
- [ ] Images are clickable (if lightbox implemented)
- [ ] Lazy loading works (images load as you scroll)

#### Test: Video Display
- [ ] Video player shows
- [ ] Play button works
- [ ] Pause button works
- [ ] Volume control works
- [ ] Seek bar works
- [ ] Fullscreen works
- [ ] Video doesn't autoplay

#### Test: Filtering
- [ ] "All Districts" shows all reports
- [ ] Selecting district filters correctly
- [ ] Filter updates feed dynamically

**Test Filtering:**
```javascript
// Submit reports from different districts
// Then test filter:
1. Select "All Districts" → See all reports
2. Select "Dhaka" → See only Dhaka reports
3. Select "Chattogram" → See only Chattogram reports
```

---

### 6. API Endpoints

#### Test: Constituencies API
```bash
# Get all constituencies for Dhaka
curl http://localhost:3000/api/constituencies?district=Dhaka

# Expected: 20 constituencies
# Status: 200 OK
```

#### Test: Reports List API
```bash
# Get verified reports
curl http://localhost:3000/api/reports/list?status=verified

# Expected: Array of reports
# Status: 200 OK
```

#### Test: Report Submit API
```bash
# This is tested through the form
# But you can also test with curl:
curl -X POST http://localhost:3000/api/reports/submit \
  -F "district=Dhaka" \
  -F "constituency=DHAKA-1" \
  -F "votingCenterNumber=VC-123" \
  -F "description=Test" \
  -F "media=@test-image.jpg"

# Expected: Success response
# Status: 201 Created
```

---

### 7. Database Operations

#### Test: View All Tables
```sql
-- Connect to database
docker exec -it shadhin-vote-db psql -U postgres -d election_monitor

-- List all tables
\dt

-- Should see:
-- reports
-- constituencies
-- admins
-- rate_limits
-- audit_logs
```

#### Test: Query Reports
```sql
-- View all reports
SELECT * FROM reports;

-- View reports by district
SELECT * FROM reports WHERE district = 'Dhaka';

-- View verified reports
SELECT * FROM reports WHERE status = 'verified';

-- Count reports by status
SELECT status, COUNT(*) FROM reports GROUP BY status;
```

#### Test: Query Constituencies
```sql
-- View all constituencies
SELECT * FROM constituencies LIMIT 10;

-- View constituencies by district
SELECT * FROM constituencies WHERE district = 'Dhaka';

-- Count constituencies
SELECT COUNT(*) FROM constituencies;
-- Should return: 300

-- Count by district
SELECT district, COUNT(*) FROM constituencies GROUP BY district ORDER BY COUNT(*) DESC;
```

---

### 8. Performance Testing

#### Test: Page Load Speed
- [ ] Homepage loads in < 2 seconds
- [ ] Images load progressively
- [ ] No layout shift during load

#### Test: API Response Time
```bash
# Test constituency API
Measure-Command { 
    Invoke-WebRequest -Uri "http://localhost:3000/api/constituencies?district=Dhaka" 
}

# Should be < 500ms
```

#### Test: Database Query Speed
```sql
-- Test query performance
EXPLAIN ANALYZE SELECT * FROM reports WHERE district = 'Dhaka';

-- Should use index
-- Execution time should be < 10ms
```

---

### 9. Security Testing

#### Test: SQL Injection Prevention
```bash
# Try SQL injection in district parameter
curl "http://localhost:3000/api/constituencies?district=Dhaka'; DROP TABLE reports;--"

# Should return error or empty result
# Table should NOT be dropped
```

#### Test: File Upload Security
- [ ] Cannot upload .exe files
- [ ] Cannot upload .php files
- [ ] Cannot upload files over 20MB
- [ ] File types are validated

#### Test: Rate Limiting
```bash
# Submit 4 reports quickly
# 4th submission should be rate limited

# Expected: 429 Too Many Requests
```

---

### 10. Error Handling

#### Test: Database Connection Error
```powershell
# Stop database
docker-compose stop postgres

# Try to load page
# Should show error message gracefully

# Restart database
docker-compose start postgres
```

#### Test: Invalid Data
- [ ] Submit form with invalid voting center format
- [ ] Submit form with invalid GPS coordinates
- [ ] Submit form with too long description (> 300 chars)

---

## 🐛 Common Issues & Solutions

### Issue: Database Connection Failed
```powershell
# Solution: Restart database
docker-compose restart postgres

# Check logs
docker-compose logs postgres
```

### Issue: Port 3000 Already in Use
```powershell
# Solution: Use different port
$env:PORT=3001
npm run dev
```

### Issue: UploadThing Upload Fails
```powershell
# Solution: Check .env file
# Verify UPLOADTHING_TOKEN is set correctly
cat .env | Select-String "UPLOADTHING"
```

### Issue: Constituencies Not Loading
```powershell
# Solution: Re-import data
docker cp database/constituencies.sql shadhin-vote-db:/tmp/constituencies.sql
docker exec -i shadhin-vote-db psql -U postgres -d election_monitor -f /tmp/constituencies.sql
```

---

## 📊 Test Results Template

```
=== Shadhin Vote Monitor - Test Results ===
Date: __________
Tester: __________

[ ] Homepage loads correctly
[ ] District dropdown (64 districts)
[ ] Constituency dropdown (dynamic)
[ ] Image upload works
[ ] Video upload works
[ ] Report submission successful
[ ] Reports display in feed
[ ] Video playback works
[ ] Image display works
[ ] Filtering works
[ ] API endpoints respond
[ ] Database queries work
[ ] Performance acceptable
[ ] Security measures working
[ ] Error handling graceful

Issues Found:
1. ___________________________
2. ___________________________
3. ___________________________

Overall Status: [ ] PASS  [ ] FAIL
```

---

## 🎯 Acceptance Criteria

### Minimum Requirements
✅ All 64 districts selectable
✅ All 300 constituencies available
✅ File upload functional (images & videos)
✅ Reports save to database
✅ Reports display in feed
✅ Videos are playable
✅ Images are visible
✅ Filtering works
✅ No critical errors

### Nice to Have
- [ ] Fast page load (< 2s)
- [ ] Smooth animations
- [ ] Mobile responsive
- [ ] Accessibility features
- [ ] Admin panel functional

---

## 🚀 Production Readiness Checklist

Before deploying to production:

### Security
- [ ] Change default database password
- [ ] Update JWT_SECRET
- [ ] Enable HTTPS
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Add reCAPTCHA

### Performance
- [ ] Enable caching
- [ ] Optimize images
- [ ] Minify CSS/JS
- [ ] Enable compression
- [ ] Use CDN for static assets

### Monitoring
- [ ] Set up error logging
- [ ] Configure analytics
- [ ] Monitor database performance
- [ ] Set up alerts
- [ ] Regular backups

---

## 📞 Support

If tests fail:
1. Check `FULLSTACK_SETUP.md` for setup instructions
2. Review `API.md` for API documentation
3. Check Docker logs: `docker-compose logs -f`
4. Verify `.env` configuration
5. Restart services: `docker-compose restart`

**Happy Testing! 🧪✅**
