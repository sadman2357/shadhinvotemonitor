# Video & Image Display in Feed - Implementation Guide

## Overview
This guide explains how uploaded videos and images are displayed in the live reports feed.

## How It Works

### 1. File Upload Flow
```
User uploads file → UploadThing processes → File URL returned → Stored in database → Displayed in feed
```

### 2. Database Storage
When a report is submitted, the following is stored:
```sql
media_url: 'https://utfs.io/f/abc123...'  -- UploadThing URL
media_type: 'image/jpeg' or 'video/mp4'   -- File type
media_thumbnail_url: 'https://...'         -- Thumbnail (if generated)
```

### 3. Feed Display

#### For Images
```html
<img src="https://utfs.io/f/abc123..." alt="Report evidence">
```

#### For Videos
```html
<video controls>
  <source src="https://utfs.io/f/abc123..." type="video/mp4">
</video>
```

## Implementation

### Step 1: Update Report Card HTML
The report cards in the feed need to display actual media:

```html
<article class="report-card">
    <!-- For Images -->
    <img class="report-image" 
         src="{{media_url}}" 
         alt="Evidence from {{constituency}}">
    
    <!-- For Videos -->
    <video class="report-video" controls>
        <source src="{{media_url}}" type="{{media_type}}">
    </video>
    
    <div class="report-content">
        <div class="report-meta">
            <div class="report-location">{{constituency}}</div>
            <span class="report-status">{{status}}</span>
        </div>
        <p class="report-time">{{time_ago}}</p>
    </div>
</article>
```

### Step 2: Fetch Reports from API
```javascript
async function loadReports() {
    const response = await fetch('/api/reports/list?status=verified&limit=20');
    const data = await response.json();
    
    if (data.success) {
        displayReports(data.data);
    }
}
```

### Step 3: Display Reports Dynamically
```javascript
function displayReports(reports) {
    const grid = document.getElementById('reportsGrid');
    grid.innerHTML = '';
    
    reports.forEach(report => {
        const card = createReportCard(report);
        grid.appendChild(card);
    });
}

function createReportCard(report) {
    const card = document.createElement('article');
    card.className = 'report-card';
    
    // Create media element (image or video)
    let mediaElement;
    if (report.media_type.startsWith('image/')) {
        mediaElement = document.createElement('img');
        mediaElement.src = report.media_url;
        mediaElement.alt = `Evidence from ${report.constituency}`;
        mediaElement.className = 'report-image';
    } else if (report.media_type.startsWith('video/')) {
        mediaElement = document.createElement('video');
        mediaElement.controls = true;
        mediaElement.className = 'report-video';
        
        const source = document.createElement('source');
        source.src = report.media_url;
        source.type = report.media_type;
        mediaElement.appendChild(source);
    }
    
    card.appendChild(mediaElement);
    
    // Add report content
    const content = document.createElement('div');
    content.className = 'report-content';
    content.innerHTML = `
        <div class="report-meta">
            <div class="report-location">${report.constituency}</div>
            <span class="report-status status-${report.status}">
                ${report.status}
            </span>
        </div>
        <p class="report-time">${formatTimeAgo(report.created_at)}</p>
    `;
    
    card.appendChild(content);
    
    return card;
}
```

### Step 4: Add CSS for Video Display
```css
.report-video {
    width: 100%;
    height: 200px;
    object-fit: cover;
    background-color: #000;
}

.report-image {
    width: 100%;
    height: 200px;
    object-fit: cover;
}
```

## Features

### ✅ Image Display
- Images are displayed with proper aspect ratio
- Lazy loading for performance
- Click to view full size (optional)

### ✅ Video Display
- Videos have native browser controls
- Play/pause functionality
- Volume control
- Fullscreen option

### ✅ Performance
- Thumbnails loaded first (if available)
- Videos don't autoplay
- Lazy loading for off-screen content

## Example Report Card Output

```html
<!-- Image Report -->
<article class="report-card">
    <img class="report-image" 
         src="https://utfs.io/f/abc123.jpg" 
         alt="Evidence from DHAKA-1">
    <div class="report-content">
        <div class="report-meta">
            <div class="report-location">DHAKA-1</div>
            <span class="report-status status-verified">Verified</span>
        </div>
        <p class="report-time">2 hours ago</p>
    </div>
</article>

<!-- Video Report -->
<article class="report-card">
    <video class="report-video" controls>
        <source src="https://utfs.io/f/xyz789.mp4" type="video/mp4">
    </video>
    <div class="report-content">
        <div class="report-meta">
            <div class="report-location">CHATTOGRAM-5</div>
            <span class="report-status status-verified">Verified</span>
        </div>
        <p class="report-time">5 hours ago</p>
    </div>
</article>
```

## Testing

### 1. Upload a Test File
```bash
# Start server
npm run dev

# Navigate to http://localhost:3000
# Fill out report form
# Upload an image or video
# Submit report
```

### 2. Verify in Database
```sql
SELECT media_url, media_type FROM reports ORDER BY created_at DESC LIMIT 1;
```

### 3. Check Feed Display
- Navigate to "Live Reports" section
- Verify media is displayed
- For videos: click play button
- For images: verify image loads

## Troubleshooting

### Media Not Displaying
- Check `media_url` in database
- Verify UploadThing URL is accessible
- Check browser console for errors

### Video Won't Play
- Verify file is MP4 format
- Check video codec compatibility
- Ensure file size is under 20MB

### Images Not Loading
- Check CORS settings
- Verify image URL is valid
- Check file format (JPG/PNG only)

## Security Considerations

### ✅ Content Validation
- Only verified reports shown in public feed
- File types validated on upload
- File size limits enforced

### ✅ Privacy
- No EXIF data exposed
- IP addresses hashed
- Anonymous submissions

### ✅ Performance
- CDN delivery via UploadThing
- Lazy loading implemented
- Thumbnail generation (optional)

## Next Steps

1. **Implement dynamic loading** in `index-standalone.html`
2. **Add pagination** for large number of reports
3. **Add filtering** by district/constituency
4. **Add lightbox** for full-size image viewing
5. **Add video player controls** customization

---

**Status**: Ready to implement in the feed!
